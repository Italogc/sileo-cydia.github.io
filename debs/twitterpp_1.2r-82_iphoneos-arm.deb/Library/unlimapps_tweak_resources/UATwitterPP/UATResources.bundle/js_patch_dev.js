require('NSNumber,NSString');
defineClass('TNLMutableParameterCollection', {
    setParameterValue_forKey: function(value, key) {
    	self.ORIGsetParameterValue_forKey(value, key);
        if (key.isEqualToString(NSString.stringWithString("status")) && self.parameters().objectForKey(NSString.stringWithString("tweet_mode"))) {
            self.ORIGsetParameterValue_forKey(NSNumber.numberWithInt(1), NSString.stringWithString("weighted_character_count"));
        }
    },
});

defineClass('TFNTwitterAccount', {
    maximumCharacterCount: function() {
        return 280;
    },
});

defineClass('CLSCrashReportingController', {
    startCrashReporterWithAPIKey_betaToken_profilingMark_report: function(arg1, arg2, arg3, arg4) {
        return false;
    },
    crashReportingSetupCompleted: function(arg1) {
    	
    },
    startWithProfilingMark_betaToken: function(arg1, arg2) {
        return false;
    },
});